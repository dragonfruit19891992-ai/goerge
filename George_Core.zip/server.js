import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';

const app = express();
app.use(cors());
app.use(express.json({ limit: '50mb' }));

const PORT = 8000;
const OLLAMA_GENERATE_URL = 'http://127.0.0.1:11434/api/generate';
const OLLAMA_EMBED_URL = 'http://127.0.0.1:11434/api/embeddings';

// Hardcoded Sovereign Base Path
const BASE_PATH = 'C:\\Users\\meagh\\Downloads';
const MEMORY_FILE = path.join('C:\\Users\\meagh', 'george_memory.json');

if (!fs.existsSync(MEMORY_FILE)) {
    fs.writeFileSync(MEMORY_FILE, JSON.stringify({ chunks: [] }, null, 2));
}

// Simple Cosine Similarity
function cosineSimilarity(A, B) {
    let dot = 0, mA = 0, mB = 0;
    for(let i=0; i<A.length; i++){
        dot += A[i]*B[i];
        mA += A[i]*A[i];
        mB += B[i]*B[i];
    }
    if (mA === 0 || mB === 0) return 0;
    return dot / (Math.sqrt(mA) * Math.sqrt(mB));
}

async function getEmbedding(text, model = 'llama3') {
    try {
        const response = await fetch(OLLAMA_EMBED_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ model: model, prompt: text })
        });
        const data = await response.json();
        return data.embedding;
    } catch(err) {
        console.error("Embedding Error:", err);
        return null;
    }
}

// ==========================================
// SSE Live Sync Stream
// ==========================================
let sseClients = [];

app.get('/api/sync-stream', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();

    sseClients.push(res);
    // Send immediate initial sync status
    res.write(`data: ${JSON.stringify({ type: 'init', message: 'Connected to George Core' })}\n\n`);

    req.on('close', () => {
        sseClients = sseClients.filter(client => client !== res);
    });
});

function broadcastEvent(payload) {
    const message = `data: ${JSON.stringify(payload)}\n\n`;
    sseClients.forEach(client => client.write(message));
}

// ==========================================
// File Explorer API
// ==========================================
function buildFileTree(dir) {
    let results = [];
    try {
        const list = fs.readdirSync(dir);
        list.forEach(file => {
            const filePath = path.join(dir, file);
            const stat = fs.statSync(filePath);
            if (stat && stat.isDirectory()) {
                results.push({
                    name: file,
                    type: 'directory',
                    path: filePath.replace(BASE_PATH, ''),
                    children: buildFileTree(filePath)
                });
            } else {
                results.push({
                    name: file,
                    type: 'file',
                    path: filePath.replace(BASE_PATH, '')
                });
            }
        });
    } catch(e) {
        console.error("Error reading dir:", e.message);
    }
    return results;
}

app.get('/api/file-tree', (req, res) => {
    if (!fs.existsSync(BASE_PATH)) {
        return res.status(404).json({ error: 'Base path not found on server.' });
    }
    const tree = buildFileTree(BASE_PATH);
    res.json(tree);
});

app.post('/api/read-file', (req, res) => {
    const { relativePath } = req.body;
    const targetPath = path.join(BASE_PATH, relativePath);

    // SECURITY: Ensure we don't break out of BASE_PATH
    if (!targetPath.startsWith(BASE_PATH)) {
        return res.status(403).json({ error: 'Access denied: Path traversal attempt.' });
    }

    try {
        if (!fs.existsSync(targetPath)) return res.status(404).json({ error: 'File not found.' });
        const content = fs.readFileSync(targetPath, 'utf8');
        res.json({ content });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ==========================================
// RAG Auto-Indexing Logic
// ==========================================
async function runIndexer() {
    let memory = { chunks: [] };
    if (fs.existsSync(MEMORY_FILE)) {
        try {
            memory = JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf8'));
        } catch(e) { memory = { chunks: [] }; }
    }

    function walkDir(dir) {
        let results = [];
        try {
            const list = fs.readdirSync(dir);
            list.forEach(file => {
                file = path.join(dir, file);
                const stat = fs.statSync(file);
                if (stat && stat.isDirectory()) {
                    results = results.concat(walkDir(file));
                } else {
                    if (file.endsWith('.txt') || file.endsWith('.js') || file.endsWith('.md') || file.endsWith('.json') || file.endsWith('.html')) {
                        results.push(file);
                    }
                }
            });
        } catch(e) {}
        return results;
    }

    const files = walkDir(BASE_PATH);
    let indexedCount = 0;

    for (const file of files) {
        // Skip massive files or non-text files quickly
        const stat = fs.statSync(file);
        if (stat.size > 1024 * 500) continue; // Skip files > 500KB

        try {
            const text = fs.readFileSync(file, 'utf8').substring(0, 2000);
            // Quick check if already indexed recently (very naive deduplication)
            const existingChunk = memory.chunks.find(c => c.path === file && c.text === text);
            if(existingChunk) {
                indexedCount++;
                continue;
            }

            const embedding = await getEmbedding(text);
            if (embedding) {
                memory.chunks = memory.chunks.filter(c => c.path !== file);
                memory.chunks.push({
                    path: file,
                    text: text,
                    embedding: embedding
                });
            }
        } catch(e) {}
        indexedCount++;
    }

    fs.writeFileSync(MEMORY_FILE, JSON.stringify(memory));
    return indexedCount;
}

// ==========================================
// Auto-Watch God Engine
// ==========================================
let debounceTimer;

function startAutoWatch() {
    if (!fs.existsSync(BASE_PATH)) {
        console.error(`[ERROR] Base path ${BASE_PATH} does not exist. Cannot start watcher.`);
        return;
    }

    console.log(`[DAEMON] Mounting God-Mode Watcher on: ${BASE_PATH}`);
    
    // Initial Indexing Fire
    runIndexer().then(count => {
        console.log(`[DAEMON] Initial indexing complete. Synchronized ${count} files.`);
    });

    // Native Windows File Watcher
    fs.watch(BASE_PATH, { recursive: true }, (eventType, filename) => {
        if (filename) {
            clearTimeout(debounceTimer);
            broadcastEvent({ type: 'sync_pulse', status: 'syncing', file: filename });
            
            debounceTimer = setTimeout(async () => {
                console.log(`[DAEMON] Auto-healing memory due to change in ${filename}...`);
                const count = await runIndexer();
                broadcastEvent({ type: 'sync_pulse', status: 'synced', indexedCount: count });
                broadcastEvent({ type: 'file_tree_update' }); // Tell UI to refresh the explorer
                console.log(`[DAEMON] Memory successfully self-healed.`);
            }, 3000);
        }
    });
}

// Start watching immediately on boot!
startAutoWatch();


// ==========================================
// Core Endpoints
// ==========================================
app.get('/api/status', (req, res) => {
    res.json({ status: 'online', name: 'George Sovereign Daemon', basePath: BASE_PATH });
});

app.post('/api/chat', async (req, res) => {
    const { prompt, model = 'llama3' } = req.body;
    try {
        const promptEmbedding = await getEmbedding(prompt, model);
        let contextText = "";

        if (promptEmbedding && fs.existsSync(MEMORY_FILE)) {
            const memory = JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf8'));
            const scoredChunks = memory.chunks.map(chunk => {
                return { ...chunk, score: cosineSimilarity(promptEmbedding, chunk.embedding) };
            });
            scoredChunks.sort((a, b) => b.score - a.score);
            const topChunks = scoredChunks.slice(0, 3);
            
            if (topChunks.length > 0 && topChunks[0].score > 0.5) {
                contextText = "CONTEXT FROM FILES:\n" + topChunks.map(c => `File: ${c.path}\nContent: ${c.text}`).join('\n\n') + "\n\n";
            }
        }

        const finalPrompt = contextText ? `${contextText}Based on the above context, answer the following: ${prompt}` : prompt;

        const response = await fetch(OLLAMA_GENERATE_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: model,
                prompt: finalPrompt,
                stream: false
            })
        });

        if (!response.ok) throw new Error(`Ollama Error: ${response.statusText}`);
        const data = await response.json();
        res.json({ response: data.response, injectedContext: !!contextText });
    } catch (error) {
        res.status(500).json({ error: 'Failed to connect to local Ollama instance.' });
    }
});

app.listen(PORT, () => {
    console.log(`========================================`);
    console.log(`GEORGE SOVEREIGN DAEMON running on Port ${PORT}`);
    console.log(`Zero-Click Auto-Mount Engine Online.`);
    console.log(`========================================`);
});
